<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width">
    <title>CarPlug</title>
    <meta name="description" content="The California Plug Load Research Center (CalPlug) was established to improve energy efficiency in the use and design of appliances and consumer electronic devices. The Center has already earned research funding support from the California Energy Commission, for $1 million." />
    <meta name="keywords" content="calplug, energy, power saving" />
    <link rel="stylesheet" type="text/css" href="css/style.css" />

      <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
      <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
      <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
      <script src="js/action.js"></script>

  <script>
  </script>

</head>
<body>
<div class="wapper">
    <div class="notification">
        <h2>CarPlug</h2>
        <p>Plugged in, wait for action.</p>
        <a href="#" class="optimize" onclick="plugIn();"> Optimize </a>
        <a href="#" class="charge" onclick="plugIn();"> Charge Now </a>
    </div>
    <header>
        <h3>Good evening [User], <br /> your car will be ready at: </h3>
        <h1 class="readyBy">5:30 A.M.</h1>
        <ul class="nav">
          <li class="button-dropdown">
            <a href="javascript:void(0)" class="dropdown-toggle">
              <img src="image/user-folder--v3.png" width="30">
            </a>
            <ul class="dropdown-menu">
              <li> <a href="#"> Profile 1 </a> </li>
              <li> <a href="#"> Profile 2 </a> </li>
              <li> <a href="#"> Profile 3 </a> </li>
            </ul>
          </li>
        </ul>
        <a id="opener"><img src="image/question-mark.png" width="50"></a>
    </header>
    <main>
        <section class="profile">
            <div class="user-1" onclick="user1();">EI: 20%<br />CE: 50%<br />SI: 30%<br />ETA: 5:20</div>
            <div class="user-2" onclick="user2();">EI: 25%<br />CE: 45%<br />SI: 30%<br />ETA: 5:30</div>
            <div class="user-3" onclick="user3();">EI: 20%<br />CE: 60%<br />SI: 40%<br />ETA: 5:40</div>
            <a href="#" class="refresh" onclick="chargeNow();">Refresh</a>
        </section>
        <section class="percent">
            <p>
              <div id="slider-range" style="width: 80%; margin: 0 auto; "></div>
            </p>
        </section>
        <section class="status">
            <h3>Optimization</h3>
            <div class='environmental'>Environmental Impact: <b>20%</b></div>
            <div class='cost'>Cost Efficiency: <b>20%</b></div>
            <div class='social'>Social Impact: <b>20%</b></div>
        </section>
    </main>
    <footer>
        <a href="#" class="chargenow" onclick="chargeNow();">Charge Now <img src="image/triggering.png"></a>
        <br /><br />
        <a href="#" onclick="plugIn();">Cable: Plug In</a>
    </footer>
    <div id="dialog" title="Help">
        <h3>Environmental Impact:</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
            tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
            quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo.</p>
        <h3>Cost Efficiency:</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
            tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
            quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo.</p>
        <h3>Social Impact:</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
            tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
            quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo.</p>
    </div>
</div>
<script type="module" src="action.js"></script>
</body>
</html>